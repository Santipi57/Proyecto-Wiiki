<?php

    session_start();

    if(!isset($_SESSION['usuario'])){
        echo'
        <script>
                alert("Porfavor debes iniciar sesión");
                window.location = "../Login.html";
        </script>
        ';
        header("location:Login.html");
        session_destroy();
        die();
    }

?>


<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://kit.fontawesome.com/4f85c2f6ef.js" crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
  <link rel="StyleSheet" href="estilo.css" type="text/css" media="screen">
  <link rel="StyleSheet" href="css/nav.css" type="text/css" media="screen">

  <link rel="icon" href="images/zorro.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>Wikii</title>
</head>
<body>
 <header class="header">
  <nav class="nav">
  <a href="#" class="logo"><img src="images/logo.png"></a>
  <button class="nav-toggle">
   <i class="fas fa-bars"></i>
    </button>
     <ul class="nav-menu">
   <li class="nav-menu-item">
    <a href="cursos.html" class="nav-menu-link nav-link">Cursos</a>
   </li>
   <li class="nav-menu-item">
           <a href="perfil.html" class="nav-menu-link nav-link">Perfil</a>
          </li>
          <li class="nav-menu-item">
           <a href="acercade.html" class="nav-menu-link nav-link">Quienes somos?</a>
   </li>
          <li class="nav-menu-item">
           <a href="contacto.html" class="nav-menu-link nav-link nav-menu-link_active">Contacto</a>
          </li>
          <li class="nav-menu-item">
           <a href="web/index.html" class="nav-menu-link nav-link">Nuestros clientes</a>
          </li>
          <button class="switch" id="switch">
           <span><i class="fas fa-sun"></i></span>
           <span><i class="fas fa-moon"></i></span>
          </button>
         </ul>
        </nav>
      </header>
    <section class="banner contenedor">
      <secrion class="banner_title">
        <h2>¡Bienvenido a Wikii!</h2>
        <a href="php/sign_up.html"><input type="button" value="Registrarse" class=".iz"></a>
        <a href="php/login.html"><input type="button" value="Ingresar" class="in" ></a>
      </secrion>
      <div class="banner_img">
       <img src="images/zorro.png" alt="Logo">

      </div>
    </section>
    <!--eliminado por lag
    <div class="burbujas">
      <div class="burbuja"></div>
      <div class="burbuja"></div>
      <div class="burbuja"></div>
      <div class="burbuja"></div>
      <div class="burbuja"></div>
      <div class="burbuja"></div>
      <div class="burbuja"></div>
      <div class="burbuja"></div>
      <div class="burbuja"></div>
      <div class="burbuja"></div>
    </div>-->
  </div>
  <section class="section">
  <div class="wave"></div>
  </section>
  <script src="js/main.js"></script>
  <script src="index.js"></script>
  
 </header>
</body>
</html>
